// Função principal do jogo, chamada pelos botões no HTML
function jogar(escolhaUsuario) {
    // a. O usuário faz uma escolha (passada como argumento da função)

    // b. O computador faz uma escolha
    const escolhaComputador = obterEscolhaComputador();

    // c. Determina o vencedor
    const resultado = determinarVencedor(escolhaUsuario, escolhaComputador);

    // Exibe o resultado na tela
    const elementoResultado = document.getElementById('resultado');
    elementoResultado.innerHTML = `
        <p>Você escolheu: <strong>${escolhaUsuario}</strong></p>
        <p>O computador escolheu: <strong>${escolhaComputador}</strong></p>
        <p style="font-size: 1.5em; color: #ff6600;">${resultado}</p>
    `;
}

// Função para o computador fazer uma escolha aleatória
function obterEscolhaComputador() {
    // Gera um número flutuante entre 0 (inclusivo) e 1 (exclusivo)
    const aleatorio = Math.random();

    // Divide 0.99 em 3 partes (aproximadamente 0.33 cada)
    if (aleatorio < 0.33) {
        return 'pedra';
    } else if (aleatorio < 0.66) {
        return 'papel';
    } else {
        return 'tesoura';
    }
}

// Função para determinar o vencedor com base nas duas escolhas
function determinarVencedor(usuario, computador) {
    // Verifica empate
    if (usuario === computador) {
        return 'Empate! 🤝';
    }

    // Verifica as condições de vitória do usuário
    if (
        (usuario === 'pedra' && computador === 'tesoura') ||
        (usuario === 'tesoura' && computador === 'papel') ||
        (usuario === 'papel' && computador === 'pedra')
    ) {
        return 'Você venceu! 🎉';
    } else {
        return 'Você perdeu! 😢';
    }
}
