const funcionario1 = {
    matricula: 133297,
    nome: "Hugo Henrique",
    funcao: "Programador"
}

const funcionario2 = {
    matricula: 133298,
    nome: "Sara Carolina",
    funcao: "Designer UI/UX"
}

const funcionario3 = {
    matricula: 133299,
    nome: "Lucas Mendes",
    funcao: "Analista de Sistemas"
}

class funcionario4 {
    constructor(matricula, nome, idade){
        this.nome = nome
        this.matricula = matricula
        this.idade = idade
    }
}

const funcionarioA = new Funcionario4(133300, "Carlos Silva", 34)
const funcionarioB = new Funcionario4(133301, "Mariana Oliveira", 28)
const funcionarioC = new Funcionario4(133302, "Rafael Souza", 41)

function funcionario5 (matricula, nome, idade){
    this.matricula = matricula
    this.nome = nome
    this.idade = idade
}

const funcionarioX = new Funcionario5(133303, "Fernanda Lima", 29)
const funcionarioY = new Funcionario5(133304, "Diego Martins", 35)
const funcionarioZ = new Funcionario5(133305, "Júlia Alves", 24)