/**
 * Exercício 1: Função Construtora para Retângulo
 *
 * Utilize uma função construtora para o Retângulo receber (x,y) ou seja, base e altura,
 * com um método para calcular a área. Criar um objeto e executar o método que calcula a área.
 */

// 1. Definição da função construtora 'Retangulo'
function Retangulo(x, y) {
  // Atribui os parâmetros 'x' e 'y' às propriedades 'base' e 'altura' do objeto
  this.base = x;
  this.altura = y;

  // 2. Definição de um método para calcular a área
  this.calcularArea = function() {
    return this.base * this.altura;
  };
}

// 3. Captura do formulário e elementos do DOM
const formRetangulo = document.getElementById('formRetangulo');
const inputBase = document.getElementById('base');
const inputAltura = document.getElementById('altura');
const resultadoDiv = document.getElementById('resultado');
const resultBase = document.getElementById('resultBase');
const resultAltura = document.getElementById('resultAltura');
const resultArea = document.getElementById('resultArea');
const errorBase = document.getElementById('errorBase');
const errorAltura = document.getElementById('errorAltura');

// 4. Event listener para o formulário
formRetangulo.addEventListener('submit', function(event) {
  event.preventDefault(); // Previne o comportamento padrão do formulário

  // Limpa as mensagens de erro anteriores
  errorBase.classList.remove('show');
  errorAltura.classList.remove('show');
  errorBase.textContent = '';
  errorAltura.textContent = '';

  // Obtém os valores dos inputs
  const base = parseFloat(inputBase.value);
  const altura = parseFloat(inputAltura.value);

  // Validação dos dados
  let temErro = false;

  if (isNaN(base) || base <= 0) {
    errorBase.textContent = 'A base deve ser um número maior que zero.';
    errorBase.classList.add('show');
    temErro = true;
  }

  if (isNaN(altura) || altura <= 0) {
    errorAltura.textContent = 'A altura deve ser um número maior que zero.';
    errorAltura.classList.add('show');
    temErro = true;
  }

  if (temErro) {
    resultadoDiv.classList.remove('show');
    return;
  }

  // 5. Criação de um novo objeto (instância) de Retangulo
  const meuRetangulo = new Retangulo(base, altura);

  // 6. Execução do método e exibição do resultado
  const area = meuRetangulo.calcularArea();

  // Exibe os resultados na página
  resultBase.textContent = meuRetangulo.base.toFixed(2);
  resultAltura.textContent = meuRetangulo.altura.toFixed(2);
  resultArea.textContent = area.toFixed(2) + ' unidades²';

  // Mostra a seção de resultado
  resultadoDiv.classList.add('show');

  // Log no console para fins de debug
  console.log('Retângulo criado:', meuRetangulo);
  console.log('Área calculada:', area);
});

// 7. Validação em tempo real (opcional, para melhor UX)
inputBase.addEventListener('blur', function() {
  if (this.value && (isNaN(parseFloat(this.value)) || parseFloat(this.value) <= 0)) {
    errorBase.textContent = 'A base deve ser um número maior que zero.';
    errorBase.classList.add('show');
  } else {
    errorBase.classList.remove('show');
  }
});

inputAltura.addEventListener('blur', function() {
  if (this.value && (isNaN(parseFloat(this.value)) || parseFloat(this.value) <= 0)) {
    errorAltura.textContent = 'A altura deve ser um número maior que zero.';
    errorAltura.classList.add('show');
  } else {
    errorAltura.classList.remove('show');
  }
});
