/**
 * Exercício 2: Classes de Conta Bancária com Herança
 *
 * Crie uma Classe tipo Conta, com as propriedades nomeCorrentista, banco, numero da conta e saldo.
 * Crie utilizando herança duas novas classes: Corrente com Saldo Especial e Poupanca com Juros, Data Vencimento.
 * Receber os dados via get e set. Criar um objeto de cada uma: Corrente e Poupanca e mostrar os seus dados.
 */

// ===== CLASSES =====

// 1. Classe base 'Conta'
class Conta {
  // Propriedades privadas para encapsulamento
  #nomeCorrentista;
  #banco;
  #numeroConta;
  #saldo;

  constructor(nomeCorrentista, banco, numeroConta, saldo) {
    this.#nomeCorrentista = nomeCorrentista;
    this.#banco = banco;
    this.#numeroConta = numeroConta;
    this.#saldo = saldo;
  }

  // Getters para acessar as propriedades
  get nomeCorrentista() {
    return this.#nomeCorrentista;
  }

  get banco() {
    return this.#banco;
  }

  get numeroConta() {
    return this.#numeroConta;
  }

  get saldo() {
    return this.#saldo;
  }

  // Setters para modificar as propriedades
  set nomeCorrentista(novoNome) {
    this.#nomeCorrentista = novoNome;
  }

  set banco(novoBanco) {
    this.#banco = novoBanco;
  }

  set numeroConta(novoNumero) {
    this.#numeroConta = novoNumero;
  }

  set saldo(novoSaldo) {
    if (novoSaldo < 0) {
      console.warn('Atenção: Saldo não pode ser negativo. Valor não alterado.');
      return;
    }
    this.#saldo = novoSaldo;
  }
}

// 2. Classe 'Corrente' que herda de 'Conta'
class Corrente extends Conta {
  #saldoEspecial;

  constructor(nomeCorrentista, banco, numeroConta, saldo, saldoEspecial) {
    // Chama o construtor da classe pai (Conta)
    super(nomeCorrentista, banco, numeroConta, saldo);
    this.#saldoEspecial = saldoEspecial;
  }

  get saldoEspecial() {
    return this.#saldoEspecial;
  }

  set saldoEspecial(novoSaldoEspecial) {
    if (novoSaldoEspecial < 0) {
      console.warn('Atenção: Saldo especial não pode ser negativo. Valor não alterado.');
      return;
    }
    this.#saldoEspecial = novoSaldoEspecial;
  }
}

// 3. Classe 'Poupanca' que herda de 'Conta'
class Poupanca extends Conta {
  #juros;
  #dataVencimento;

  constructor(nomeCorrentista, banco, numeroConta, saldo, juros, dataVencimento) {
    super(nomeCorrentista, banco, numeroConta, saldo);
    this.#juros = juros;
    this.#dataVencimento = dataVencimento;
  }

  get juros() {
    return this.#juros;
  }

  set juros(novosJuros) {
    if (novosJuros < 0) {
      console.warn('Atenção: Taxa de juros não pode ser negativa. Valor não alterado.');
      return;
    }
    this.#juros = novosJuros;
  }

  get dataVencimento() {
    return this.#dataVencimento;
  }

  set dataVencimento(novaData) {
    this.#dataVencimento = novaData;
  }
}

// ===== MANIPULAÇÃO DO DOM =====

// Formulário Corrente
const formCorrente = document.getElementById('formCorrente');
const resultadoCorrente = document.getElementById('resultadoCorrente');

// Formulário Poupança
const formPoupanca = document.getElementById('formPoupanca');
const resultadoPoupanca = document.getElementById('resultadoPoupanca');

// ===== FUNÇÕES DE VALIDAÇÃO =====

function validarCampoTexto(valor, nomeCampo) {
  if (!valor || valor.trim() === '') {
    return `${nomeCampo} é obrigatório.`;
  }
  return null;
}

function validarCampoNumero(valor, nomeCampo, minimo = 0) {
  if (isNaN(valor) || valor < minimo) {
    return `${nomeCampo} deve ser um número maior ou igual a ${minimo}.`;
  }
  return null;
}

function validarCampoData(valor, nomeCampo) {
  if (!valor) {
    return `${nomeCampo} é obrigatório.`;
  }
  return null;
}

function formatarData(dataISO) {
  const data = new Date(dataISO);
  return data.toLocaleDateString('pt-BR');
}

function formatarMoeda(valor) {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(valor);
}

// ===== EVENT LISTENERS =====

// Formulário Conta Corrente
formCorrente.addEventListener('submit', function(event) {
  event.preventDefault();

  // Limpa erros anteriores
  document.querySelectorAll('#formCorrente .error').forEach(el => {
    el.classList.remove('show');
    el.textContent = '';
  });

  // Obtém os valores
  const nomeCorrente = document.getElementById('nomeCorrente').value;
  const bancoCorrente = document.getElementById('bancoCorrente').value;
  const numCorrente = document.getElementById('numCorrente').value;
  const saldoCorrente = parseFloat(document.getElementById('saldoCorrente').value);
  const saldoEspecial = parseFloat(document.getElementById('saldoEspecial').value);

  // Validação
  let temErro = false;

  const erroNome = validarCampoTexto(nomeCorrente, 'Nome do correntista');
  if (erroNome) {
    document.getElementById('errorNomeCorrente').textContent = erroNome;
    document.getElementById('errorNomeCorrente').classList.add('show');
    temErro = true;
  }

  const erroBanco = validarCampoTexto(bancoCorrente, 'Banco');
  if (erroBanco) {
    document.getElementById('errorBancoCorrente').textContent = erroBanco;
    document.getElementById('errorBancoCorrente').classList.add('show');
    temErro = true;
  }

  const erroNum = validarCampoTexto(numCorrente, 'Número da conta');
  if (erroNum) {
    document.getElementById('errorNumCorrente').textContent = erroNum;
    document.getElementById('errorNumCorrente').classList.add('show');
    temErro = true;
  }

  const erroSaldo = validarCampoNumero(saldoCorrente, 'Saldo inicial');
  if (erroSaldo) {
    document.getElementById('errorSaldoCorrente').textContent = erroSaldo;
    document.getElementById('errorSaldoCorrente').classList.add('show');
    temErro = true;
  }

  const erroEspecial = validarCampoNumero(saldoEspecial, 'Saldo especial');
  if (erroEspecial) {
    document.getElementById('errorSaldoEspecial').textContent = erroEspecial;
    document.getElementById('errorSaldoEspecial').classList.add('show');
    temErro = true;
  }

  if (temErro) {
    resultadoCorrente.classList.remove('show');
    return;
  }

  // Cria a instância de Corrente
  const contaCorrente = new Corrente(nomeCorrente, bancoCorrente, numCorrente, saldoCorrente, saldoEspecial);

  // Exibe os resultados
  document.getElementById('resultNomeCorrente').textContent = contaCorrente.nomeCorrentista;
  document.getElementById('resultBancoCorrente').textContent = contaCorrente.banco;
  document.getElementById('resultNumCorrente').textContent = contaCorrente.numeroConta;
  document.getElementById('resultSaldoCorrente').textContent = formatarMoeda(contaCorrente.saldo);
  document.getElementById('resultSaldoEspecialCorrente').textContent = formatarMoeda(contaCorrente.saldoEspecial);

  resultadoCorrente.classList.add('show');

  console.log('Conta Corrente criada:', contaCorrente);
});

// Formulário Conta Poupança
formPoupanca.addEventListener('submit', function(event) {
  event.preventDefault();

  // Limpa erros anteriores
  document.querySelectorAll('#formPoupanca .error').forEach(el => {
    el.classList.remove('show');
    el.textContent = '';
  });

  // Obtém os valores
  const nomePoupanca = document.getElementById('nomePoupanca').value;
  const bancoPoupanca = document.getElementById('bancoPoupanca').value;
  const numPoupanca = document.getElementById('numPoupanca').value;
  const saldoPoupanca = parseFloat(document.getElementById('saldoPoupanca').value);
  const juros = parseFloat(document.getElementById('juros').value);
  const dataVencimento = document.getElementById('dataVencimento').value;

  // Validação
  let temErro = false;

  const erroNome = validarCampoTexto(nomePoupanca, 'Nome do correntista');
  if (erroNome) {
    document.getElementById('errorNomePoupanca').textContent = erroNome;
    document.getElementById('errorNomePoupanca').classList.add('show');
    temErro = true;
  }

  const erroBanco = validarCampoTexto(bancoPoupanca, 'Banco');
  if (erroBanco) {
    document.getElementById('errorBancoPoupanca').textContent = erroBanco;
    document.getElementById('errorBancoPoupanca').classList.add('show');
    temErro = true;
  }

  const erroNum = validarCampoTexto(numPoupanca, 'Número da conta');
  if (erroNum) {
    document.getElementById('errorNumPoupanca').textContent = erroNum;
    document.getElementById('errorNumPoupanca').classList.add('show');
    temErro = true;
  }

  const erroSaldo = validarCampoNumero(saldoPoupanca, 'Saldo inicial');
  if (erroSaldo) {
    document.getElementById('errorSaldoPoupanca').textContent = erroSaldo;
    document.getElementById('errorSaldoPoupanca').classList.add('show');
    temErro = true;
  }

  const erroJuros = validarCampoNumero(juros, 'Taxa de juros');
  if (erroJuros) {
    document.getElementById('errorJuros').textContent = erroJuros;
    document.getElementById('errorJuros').classList.add('show');
    temErro = true;
  }

  const erroData = validarCampoData(dataVencimento, 'Data de vencimento');
  if (erroData) {
    document.getElementById('errorDataVencimento').textContent = erroData;
    document.getElementById('errorDataVencimento').classList.add('show');
    temErro = true;
  }

  if (temErro) {
    resultadoPoupanca.classList.remove('show');
    return;
  }

  // Cria a instância de Poupanca
  const contaPoupanca = new Poupanca(nomePoupanca, bancoPoupanca, numPoupanca, saldoPoupanca, juros, dataVencimento);

  // Exibe os resultados
  document.getElementById('resultNomePoupanca').textContent = contaPoupanca.nomeCorrentista;
  document.getElementById('resultBancoPoupanca').textContent = contaPoupanca.banco;
  document.getElementById('resultNumPoupanca').textContent = contaPoupanca.numeroConta;
  document.getElementById('resultSaldoPoupanca').textContent = formatarMoeda(contaPoupanca.saldo);
  document.getElementById('resultJuros').textContent = contaPoupanca.juros.toFixed(2) + '%';
  document.getElementById('resultDataVencimento').textContent = formatarData(contaPoupanca.dataVencimento);

  resultadoPoupanca.classList.add('show');

  console.log('Conta Poupança criada:', contaPoupanca);
});
