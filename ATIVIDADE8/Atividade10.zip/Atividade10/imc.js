/**
 * Calculadora de IMC - Arquivo JavaScript
 * Funções para calcular e exibir o Índice de Massa Corporal
 */

/**
 * Calcula o IMC baseado em altura e peso
 * @param {number} altura - Altura em metros
 * @param {number} peso - Peso em quilogramas
 * @returns {number} - O valor do IMC arredondado para 2 casas decimais
 */
function calcularIMC() {
    // Obter valores dos inputs
    const altura = parseFloat(document.getElementById('altura').value);
    const peso = parseFloat(document.getElementById('peso').value);
    const erroDiv = document.getElementById('erro');
    const resultadoDiv = document.getElementById('resultado');

    // Limpar mensagens de erro anteriores
    erroDiv.classList.remove('ativo');
    erroDiv.textContent = '';

    // Validar entrada
    if (!altura || !peso) {
        exibirErro('Por favor, preencha todos os campos!');
        resultadoDiv.classList.remove('ativo');
        return;
    }

    if (altura <= 0 || altura > 2.5) {
        exibirErro('Altura deve estar entre 0,5m e 2,5m!');
        resultadoDiv.classList.remove('ativo');
        return;
    }

    if (peso <= 0 || peso > 500) {
        exibirErro('Peso deve estar entre 1kg e 500kg!');
        resultadoDiv.classList.remove('ativo');
        return;
    }

    // Calcular IMC: peso / (altura²)
    const imc = peso / (altura * altura);
    const imcArredondado = imc.toFixed(2);

    // Obter classificação
    const classificacao = obterClassificacao(imc);

    // Exibir resultado
    exibirResultado(imcArredondado, classificacao);
}

/**
 * Determina a classificação do IMC
 * @param {number} imc - Valor do IMC
 * @returns {object} - Objeto com classificação, grau e classe CSS
 */
function obterClassificacao(imc) {
    if (imc < 18.5) {
        return {
            classificacao: 'Magreza',
            grau: '0',
            classe: 'magreza',
            descricao: 'Você está abaixo do peso ideal. Considere consultar um nutricionista.'
        };
    } else if (imc >= 18.5 && imc < 25) {
        return {
            classificacao: 'Normal',
            grau: '0',
            classe: 'normal',
            descricao: 'Parabéns! Seu peso está dentro da faixa normal e saudável.'
        };
    } else if (imc >= 25 && imc < 30) {
        return {
            classificacao: 'Sobrepeso',
            grau: 'I',
            classe: 'sobrepeso',
            descricao: 'Você está com sobrepeso. Recomenda-se atividade física regular.'
        };
    } else if (imc >= 30 && imc < 40) {
        return {
            classificacao: 'Obesidade',
            grau: 'II',
            classe: 'obesidade',
            descricao: 'Você está com obesidade. Procure um profissional de saúde.'
        };
    } else {
        return {
            classificacao: 'Obesidade Grave',
            grau: 'III',
            classe: 'obesidade-grave',
            descricao: 'Você está com obesidade grave. Procure ajuda médica urgentemente.'
        };
    }
}

/**
 * Exibe o resultado do cálculo de IMC
 * @param {string} imc - Valor do IMC formatado
 * @param {object} classificacao - Objeto com dados da classificação
 */
function exibirResultado(imc, classificacao) {
    const resultadoDiv = document.getElementById('resultado');

    // Construir HTML do resultado
    const html = `
        <h2>✅ Resultado do Cálculo</h2>
        <div class="imc-valor">${imc}</div>
        <div class="classificacao"><strong>${classificacao.classificacao}</strong></div>
        <div class="grau">Grau: <strong>${classificacao.grau}</strong></div>
        <div style="margin-top: 15px; font-size: 14px; text-align: center; line-height: 1.5;">
            ${classificacao.descricao}
        </div>
    `;

    // Atualizar div com resultado
    resultadoDiv.innerHTML = html;
    resultadoDiv.className = `resultado ativo ${classificacao.classe}`;
}

/**
 * Exibe mensagem de erro
 * @param {string} mensagem - Mensagem de erro a exibir
 */
function exibirErro(mensagem) {
    const erroDiv = document.getElementById('erro');
    erroDiv.textContent = '⚠️ ' + mensagem;
    erroDiv.classList.add('ativo');
}

/**
 * Limpa todos os campos e resultados
 */
function limpar() {
    // Limpar inputs
    document.getElementById('altura').value = '';
    document.getElementById('peso').value = '';

    // Limpar resultado
    const resultadoDiv = document.getElementById('resultado');
    resultadoDiv.classList.remove('ativo');
    resultadoDiv.innerHTML = '';

    // Limpar erro
    const erroDiv = document.getElementById('erro');
    erroDiv.classList.remove('ativo');
    erroDiv.textContent = '';

    // Focar no primeiro input
    document.getElementById('altura').focus();
}

/**
 * Permite calcular pressionando Enter nos inputs
 */
document.addEventListener('DOMContentLoaded', function() {
    const alturaInput = document.getElementById('altura');
    const pesoInput = document.getElementById('peso');

    alturaInput.addEventListener('keypress', function(event) {
        if (event.key === 'Enter') {
            pesoInput.focus();
        }
    });

    pesoInput.addEventListener('keypress', function(event) {
        if (event.key === 'Enter') {
            calcularIMC();
        }
    });

    // Focar no primeiro input ao carregar
    alturaInput.focus();
});

