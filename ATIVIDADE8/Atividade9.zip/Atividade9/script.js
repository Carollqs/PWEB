
function findLargest(num1, num2, num3) {
    return Math.max(num1, num2, num3);
}

function sortNumbers(num1, num2, num3) {
    const numbers = [num1, num2, num3];
    return numbers.sort((a, b) => a - b);
}

function isPalindrome(str) {
    const cleanedStr = str.toUpperCase().replace(/[^A-Z0-9]/g, "");
    const reversedStr = cleanedStr.split("").reverse().join("");
    return cleanedStr === reversedStr;
}

function checkTriangle(side1, side2, side3) {
    if (side1 + side2 > side3 && side1 + side3 > side2 && side2 + side3 > side1) {
        if (side1 === side2 && side2 === side3) {
            return "Triângulo Equilátero";
        } else if (side1 === side2 || side1 === side3 || side2 === side3) {
            return "Triângulo Isósceles";
        } else {
            return "Triângulo Escaleno";
        }
    } else {
        return "Não é um triângulo";
    }
}

function processLargest() {
    const n1 = parseFloat(document.getElementById("num1_largest").value);
    const n2 = parseFloat(document.getElementById("num2_largest").value);
    const n3 = parseFloat(document.getElementById("num3_largest").value);
    if (isNaN(n1) || isNaN(n2) || isNaN(n3)) {
        document.getElementById("result_largest").innerHTML = "<span style=\"color: red;\">Por favor, insira três números válidos.</span>";
        return;
    }
    const result = findLargest(n1, n2, n3);
    document.getElementById("result_largest").innerHTML = `O maior número é: <span style=\"color: blue; font-weight: bold;\">${result}</span>`;
}

function processSort() {
    const n1 = parseFloat(document.getElementById("num1_sort").value);
    const n2 = parseFloat(document.getElementById("num2_sort").value);
    const n3 = parseFloat(document.getElementById("num3_sort").value);
    if (isNaN(n1) || isNaN(n2) || isNaN(n3)) {
        document.getElementById("result_sort").innerHTML = "<span style=\"color: red;\">Por favor, insira três números válidos.</span>";
        return;
    }
    const result = sortNumbers(n1, n2, n3);
    document.getElementById("result_sort").innerHTML = `Números ordenados: <span style=\"color: blue; font-weight: bold;\">${result.join(", ")}</span>`;
}

function processPalindrome() {
    const str = document.getElementById("text_palindrome").value;
    if (str.trim() === "") {
        document.getElementById("result_palindrome").innerHTML = "<span style=\"color: red;\">Por favor, insira um texto.</span>";
        return;
    }
    const result = isPalindrome(str);
    document.getElementById("result_palindrome").innerHTML = `"${str}" é palíndromo? <span style=\"color: blue; font-weight: bold;\">${result ? "Sim" : "Não"}</span>`;
}

function processTriangle() {
    const s1 = parseFloat(document.getElementById("side1_triangle").value);
    const s2 = parseFloat(document.getElementById("side2_triangle").value);
    const s3 = parseFloat(document.getElementById("side3_triangle").value);
    if (isNaN(s1) || isNaN(s2) || isNaN(s3) || s1 <= 0 || s2 <= 0 || s3 <= 0) {
        document.getElementById("result_triangle").innerHTML = "<span style=\"color: red;\">Por favor, insira três valores positivos para os lados.</span>";
        return;
    }
    const result = checkTriangle(s1, s2, s3);
    document.getElementById("result_triangle").innerHTML = `Os lados ${s1}, ${s2}, ${s3} formam um: <span style=\"color: blue; font-weight: bold;\">${result}</span>`;
}

