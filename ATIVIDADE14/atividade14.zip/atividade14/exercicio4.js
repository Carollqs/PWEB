const fs = require('fs');
const data = fs.readFileSync('files.txt');
console.log(data.toString());