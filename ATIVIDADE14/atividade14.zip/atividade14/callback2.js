const { clearScreenDown } = require("readline");

function exibeMensagensNaOrdem(mensagens, callback) {
    console.log(exibeMensagensNaOrdem);
    callback();
}
exibeMensagensNaOrdem('Essa é minha primeira mensagem exibida na ordem', function(){
    console.log('Essa é minha segunda mensagem exibida na ordem');
});