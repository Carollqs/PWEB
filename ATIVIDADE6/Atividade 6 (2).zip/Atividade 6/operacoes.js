primeiroNum = parseFloat(prompt("Digite o primeiro número"))
segundoNum = parseFloat(prompt("Digite o segundo número"))

alert("A soma é: " + (primeiroNum+segundoNum) + "\nA subtração é: " + (primeiroNum-segundoNum)
+ "\nO produto é: " + (primeiroNum*segundoNum) + "\nA divisão do 1° pelo 2°: " + (primeiroNum/segundoNum) +
"\nO resto da divisão: " + (primeiroNum%segundoNum))