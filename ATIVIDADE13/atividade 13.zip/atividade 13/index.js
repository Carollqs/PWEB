// Pega as referências dos elementos HTML que vamos manipular
const titulo = document.getElementById('titulo');
const janela = document.getElementById('janela');

let janelaEstaQuebrada = false;

function abrirJanela() {

    if (!janelaEstaQuebrada) {
        janela.src = 'janelaAberta.jpg';
        titulo.textContent = 'Janela Aberta';
    }
}

function fecharJanela() {    
    if (!janelaEstaQuebrada) {
        janela.src = 'janelaFechada.jpeg';
        titulo.textContent = 'Janela Fechada';
    }
}

function quebrarJanela() {
    janela.src = 'janelaQuebrada.jpg';
    titulo.textContent = 'Janela Quebrada';
    janelaEstaQuebrada = true;
}